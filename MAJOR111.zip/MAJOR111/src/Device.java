import org.firmata4j.I2CDevice;
import org.firmata4j.Pin;
import org.firmata4j.firmata.FirmataDevice;
import org.firmata4j.ssd1306.SSD1306;

import java.io.IOException;

public class Device {
    private static final byte i2c0 = 0x3C;
    // Declare OLed Pin addresses//
    private static final int D9 = 9;

    private static final int D10 = 10;
    // Declare pin for Ultrasonic Sensor -HC-SR04 //
    private static final int D3 = 3;
    // Declare Buzzer Pin //
    private static final String USBPort = "COM6";
    // Declare Arduino port type//
    private static FirmataDevice arduinoUnoBoard;
    //Initiating Arduino Board//
    private static SSD1306 OLEDPanel;
    //Initiating OLed panel//


    public static void main(String[] args) throws IOException {

        initiateArduino();
        setupDisplay();
        var soundTrigger = setupDevice(D9, Pin.Mode.OUTPUT);
        var echoReceiver = setupDevice(D10, Pin.Mode.INPUT);
        var buzzer = setupDevice(D3, Pin.Mode.PWM);
        // Conversion of input data from the HC-SR04 sensor//
        while (true) {
            soundTrigger.setValue(1);
            pause(0, 10000);
            soundTrigger.setValue(0);
            double distance = calculateDistance(echoReceiver);
            System.out.println(distance +" cm.");
            pause(0, 30000);
            OLEDPanel.clear();
            //If the sensor detects something//
            if (distance <= 5) {
                buzzer.setValue(66);
                OLEDPanel.getCanvas().drawString(0, 0, "Obstacle in way");
                OLEDPanel.getCanvas().drawString(0,15, "Move aside");
                OLEDPanel.display();
                //If the sensor detects pathway clear//
            } else if (distance > 5) {
                buzzer.setValue(0);
                OLEDPanel.getCanvas().drawString(0, 0, "Clear to go!");
                OLEDPanel.display();
                OLEDPanel.clear();
            }
        }
    }

    private static void initiateArduino() {
        arduinoUnoBoard = new FirmataDevice(USBPort);
        // Initiate Grove Board and return to the main program.
        try {
            arduinoUnoBoard.start();
            System.out.println("Grove Board Initiated.");
            arduinoUnoBoard.ensureInitializationIsDone();
        } catch (Exception e) {
            System.out.println("Couldn't connect to Grove Board.");
        }
    }

    private static Pin setupDevice(int pinType, Pin.Mode mode) {
        // Set up devices using the Pins//
        Pin device = arduinoUnoBoard.getPin(pinType);
        try {
            if (mode == Pin.Mode.OUTPUT) {
                device.setMode(Pin.Mode.OUTPUT);
            } else if (mode == Pin.Mode.PWM) {
                device.setMode(Pin.Mode.PWM);
            } else if (mode == Pin.Mode.INPUT) {
                device.setMode(Pin.Mode.INPUT);
            }else if (mode == Pin.Mode.ANALOG){
                device.setMode(Pin.Mode.ANALOG);
            }
        } catch (Exception e) {
            System.out.println("Couldn't connect to device.");
        }
        return device;
    }

    public static void pause(long millis, int nanos) {
        try {
            Thread.sleep(millis, nanos);
        } catch (Exception e) {
            System.out.println("Sleep error!");
        }
    }

    private static double calculateDistance(Pin echoPin) {
        long start = System.nanoTime();
        try {
            while (echoPin.getValue() == 0) {
                if (System.nanoTime() - start > 500000000) { // Timeout after 500ms //
                    throw new Exception("Timeout");
                }
            }
            start = System.nanoTime();
            while (echoPin.getValue() == 1) {
                if (System.nanoTime() - start > 500000000) { // Timeout after 500ms //
                    throw new Exception("Timeout");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        double duration = (System.nanoTime() - start)/1000.0;
        return Math.round(duration * 3.43 / 2.0)/100.0;
    }

    private static void setupDisplay() {

        // Initiate display and return to the main program //
        try {
            I2CDevice i2cObj = arduinoUnoBoard.getI2CDevice(i2c0);
            OLEDPanel = new SSD1306(i2cObj, SSD1306.Size.SSD1306_128_64);
            OLEDPanel.init();
        } catch (Exception e) {
            System.out.println("Couldn't connect to display.");
        }
        OLEDPanel.clear();
    }
}